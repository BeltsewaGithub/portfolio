import core.Station;
import junit.framework.TestCase;

import java.util.List;

public class RouteCalculatorTest extends TestCase {

    List<Station> route;
    @Override
    protected void setUp() throws Exception {

    }
    public void testGetShortestRoute() {

    }

    public void testCalculateDuration() {

    }
    @Override
    protected void tearDown() throws Exception {

    }
}
