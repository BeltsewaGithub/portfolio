package CompanyInfo;

public interface Employee {
    double getMonthSalary(Company company);
}
